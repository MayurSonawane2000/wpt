document.getElementById('myForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    let name = document.getElementById('name');
    let email = document.getElementById('email');
    let password = document.getElementById('password');

    let nameValid = validateName(name);
    let emailValid = validateEmail(email);
    let passwordValid = validatePassword(password);

    if(nameValid && emailValid && passwordValid) {
        alert('फॉर्म यशस्वीरीत्या सबमिट केला गेला आहे!');
    }
});

function validateName(input) {
    let re = /^[a-zA-Z\s]+$/;
    if(!re.test(input.value)) {
        showError(input, 'कृपया योग्य नाव प्रविष्ट करा.');
        return false;
    } else {
        showSuccess(input);
        return true;
    }
}

function validateEmail(input) {
    let re = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if(!re.test(input.value)) {
        showError(input, 'कृपया योग्य ईमेल प्रविष्ट करा.');
        return false;
    } else {
        showSuccess(input);
        return true;
    }
}

function validatePassword(input) {
    if(input.value.length < 6) {
        showError(input, 'पासवर्ड किमान ६ अक्षरे असावा.');
        return false;
    } else {
        showSuccess(input);
        return true;
    }
}

function showError(input, message) {
    let small = input.nextElementSibling;
    small.innerText = message;
    small.style.visibility = 'visible';
    input.style.borderColor = 'red';
}

function showSuccess(input) {
    let small = input.nextElementSibling;
    small.style.visibility = 'hidden';
    input.style.borderColor = 'green';
}
