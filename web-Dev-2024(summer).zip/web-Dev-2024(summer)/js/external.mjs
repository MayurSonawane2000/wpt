
export const myName ="Panchashil M Wankhede";

export let add = (num1,num2)=>{
    return num1+num2;
}

