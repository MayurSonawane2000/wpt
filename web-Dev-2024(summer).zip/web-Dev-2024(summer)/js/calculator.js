
function add(){
    // window.alert("hi")
   let no1 = document.getElementById("num1").value;
   let no2 = document.getElementById("num2").value;
  console.log(parseInt(no1)+parseInt(no2));
  document.getElementById("res").innerHTML = parseInt(no1)+parseInt(no2);
}