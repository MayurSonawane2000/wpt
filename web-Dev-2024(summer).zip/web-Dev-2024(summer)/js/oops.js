
// how to create class 
class Person{
    // data-member 
    pName="Swapnil";
    pContact=88888;
    pGender="Male";
    pAddress="Pune";
    // how to crete constructor 
    constructor(name,contact,gender,address){
     this.pName = name;
     this.pContact = contact;
     this.pGender = gender;
     this.pAddress = address;
    }

// member-function 
 personDetails(){
  console.log(`Name:${this.pName}, Contact:${this.pContact} Gender:${this.pGender} Address:${this.pAddress}`);  
 }

}
// how to create object of class 
// let personObj = new Person("Rohit",99999,"Male","Nashik");
// console.log(personObj.pName);
// personObj.personDetails();

// let personObj2 = new Person("Omkar",3333,"Male","Sangali");
// personObj2.personDetails();

// let personObj3 = new Person("Shradha",7777,"Female","Nagpur");
// personObj3.personDetails();

class Company extends Person{
    cName;
    cPost;
    clocation;
  static cPassword="Admin@123";
    constructor(name,contact,gender,address,comp,designation,location){
      super(name,contact,gender,address);
      this.cName= comp;
      this.cPost= designation;
      this.clocation = location;
    }
    personDetails(){
     console.log(`Name:${this.pName}, Contact:${this.pContact}, Gender:${this.pGender} ,Address:${this.pAddress} ,Company Name:${this.cName} Post:${this.cPost} Location:${this.clocation}`); 
    }
}

let companyObj = new Company("Anmol",44444,"Male","Nagpur","Congizant","Manager","Mumbai");
companyObj.personDetails();

let companyObj2 = new Company("Kasturi",99999,"Female","Nagpur","Hematite infotech","HR","Pune");
companyObj2.personDetails();
// accessing stattic data 
console.log(Company.cPassword); 


