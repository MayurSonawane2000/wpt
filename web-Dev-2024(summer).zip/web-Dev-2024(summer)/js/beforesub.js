function checkUID(){
    let uid = document.myform.uid.value;
    var regUID = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/; 

    if (uid.trim() == "") {
        // window.alert("this field is required");
        document.getElementById("uid").style.border= "2px solid red";
        document.getElementById("uiderr").innerHTML="user id is required";
        document.getElementById("uiderr").style.color="red";
        return false;
    }else if(!uid.match(regUID)){
        document.getElementById("uid").style.border= "2px solid red";
        document.getElementById("uiderr").innerHTML="user id must be in proper formate";
        document.getElementById("uiderr").style.color="red";
        return false;
    }else{
        document.getElementById("uid").style.border= "2px solid green";
        document.getElementById("uiderr").innerHTML="";
        // document.getElementById("uiderr").style.color="red";
    }
}

function checkTerm(){
    let uterm = document.myform.term;

    if(uterm.checked==false){
        document.getElementById("term").style.border= "2px solid red";
        document.getElementById("termerr").innerHTML="accept term and condition";
        document.getElementById("termerr").style.color="red";
    }else{
        document.getElementById("term").style.border= "2px solid green";
        document.getElementById("termerr").innerHTML="";
    }
}