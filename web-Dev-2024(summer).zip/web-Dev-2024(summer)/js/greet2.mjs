
// export class Result {
class Result {
    stdName;
    phy;
    che;
    math;
    constructor(name, p, c, m) {
        this.stdName = name;
        this.phy = p;
        this.che = c;
        this.math = m;
    }

    percentage() {
        let total = this.phy + this.che + this.math;
        let percent = (total / 300) * 100;
        return percent;
    }
    resultDetails(){
        console.log(`Name:${this.stdName} Physics:${this.phy} Chemistry:${this.che} Math:${this.math} Percentage:${this.percentage()}`);
    }

}

export default Result;