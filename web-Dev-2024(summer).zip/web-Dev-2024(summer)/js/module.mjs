
import {myName,add} from './external.mjs';
// import { Result } from './greet2.mjs';
import Result from './greet2.mjs';

console.log(myName);
console.log(add(500,400));

let resultObj = new Result("Mayuresh",95,99,98);
resultObj.resultDetails();