

export const myName = "mayur b sonawane";


export let add = (num1,num2)=>{
    return num1+num2;
}

export let sub = (num1,num2)=>{
    return num1-num2;
}


export let mul = (num1,num2)=>{
    return num1*num2;
}

export let div = (num1,num2)=>{
    return num1/num2;
}