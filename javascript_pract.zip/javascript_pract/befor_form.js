

function checked(){
    let uid = document.myform.uid.value;



    if(uid.trim()==""){
        //window.alert("this fill reqwired");

        document.getElementById("uid").style.bordr="2px solid red";
        document.getElementById("uiderr").innerHTML="user id is required";
        document.getElementById("uiderr").style.color="red";
        return false;
    }else if(!uid.match(regUID)){

        document.getElementById("uid").style.bordr="2px solid red";
        document.getElementById("uiderr").innerHTML="user id is required proper formatt";
        document.getElementById("uiderr").style.color="red";
        return false;
    } else{
        document.getElementById("uid").style.bordr="2px solid green";
        document.getElementById("uiderr").innerHTML="";
        //document.getElementById("uiderr").style.color="red";


    }

}

function checkterm(){
    let uterm = document.myform.term;
    if(uterm[0]
    )
}