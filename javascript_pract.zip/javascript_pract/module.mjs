

//import {myName,add,sub,mul,div} from './external.mjs';
import {Result, result} from './grid.mjs';

// console.log(myName);
// console.log(add(500,500));
// console.log(sub(500,500));
// console.log(mul(500,500));
// console.log(div(500,500));


let resultObj = new Result("mayuresh",95,95,95);
resultObj=resultDetail();