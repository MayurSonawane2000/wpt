
function add(){
    // window.alert("hi")
   let no1 = document.getElementById("num1").value;
   let no2 = document.getElementById("num2").value;
  console.log(parseInt(no1)+parseInt(no2));
  document.getElementById("res").innerHTML = parseInt(no1)+parseInt(no2);
}

function sub(){
    // window.alert("hi")
   let no1 = document.getElementById("num1").value;
   let no2 = document.getElementById("num2").value;
  console.log(parseInt(no1)-parseInt(no2));
  document.getElementById("res1").innerHTML = parseInt(no1)-parseInt(no2);
}
function mul(){
    // window.alert("hi")
   let no1 = document.getElementById("num1").value;
   let no2 = document.getElementById("num2").value;
  console.log(parseInt(no1)*parseInt(no2));
  document.getElementById("res2").innerHTML = parseInt(no1)*parseInt(no2);
}
function div(){
    // window.alert("hi")
   let no1 = document.getElementById("num1").value;
   let no2 = document.getElementById("num2").value;
  console.log(parseInt(no1)/parseInt(no2));
  document.getElementById("res3").innerHTML = parseInt(no1)/parseInt(no2);
}