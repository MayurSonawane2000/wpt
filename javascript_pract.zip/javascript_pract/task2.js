function sub(){
    // window.alert("hi")
   let no1 = document.getElementById("cell1").value;
   let no2 = document.getElementById("c1").value;
  console.log(parseInt(no1)=parseInt(no2));
  document.getElementById("res1").innerHTML = parseInt(no1)=parseInt(no2);
}