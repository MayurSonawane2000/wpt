


 class Result{
    stdname;
    phy;
    che;
    math;

    constructor(name,p,c,m){
        this.stdname = name
        this.phy = p;
        this.che = c;
        this.math = m;
    }


    percentage(){
        let total = this.phy+this.che+this.math;
        let percent=total/300;
        return percent;
    }

    resultDetails(){
        console.log(`name:${this.stdname}, physics:${this.phy}, chemestry:${this.che}, mathamatics:${this.math}`)
    }
}
export default Result;