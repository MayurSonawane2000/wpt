
function checkAll(){
    //window.alert("hi")

   // let uname = document.getElementById("fname").value;
    let uname = document.myform.fname.value;
    let rename = "[a-zA-Z]{3,20}";


    let uedu = document.myform.edu;


    if(uname.trim()==""){
        window.alert("this fill reqwired");
        document.getElementById("fname").focus();
        return false;
    }

    if(uname.match(rename)){
        window.alert("please select your qualification");
        document.getElementById("fname").focus();
        return false;
    }

    if(uedu[0].checked==false && uedu[1].checked==false && uedu[3].checked==false &&uedu[3].checked==false );

}