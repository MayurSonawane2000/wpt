


class person{
//data member
    pname = "mayur";
    pcontact = 8999910460;
    pgender = "male";
    paddress = "pune";

//member function
    persondetails(){
        console.log(`Name:${this.pname}, contact:${this.pcontact},gender:${this.pgender},address:${this.paddress}`);
    }
 
}



//how to create object of class

let personobj = new person("rohit",88888,"male","Nashik");
console.log(personobj.pname);
personobj.persondetails();





class company extends person {
    cName;
    cPost;
    clocation;


    constructor (name,post,contact,address,comp,designation,location){
        super(name,contact,gender,address);
        this.cName = comp;
        this.cPost = designation;
        this.clocation = location;

    }

    persondetails(){
        console.log(`Name:${this.pname}, contact:${this.pcontact},gender:${this.pgender},address:${this.paddress},Company Name:${this.cName}, post:${this.cPost}, location:${this.clocation}`);
    }
}

let companyObj = new company("anmol",4444, "male","nagpur","google","manger","mumbai")
companyObj.persondetails();